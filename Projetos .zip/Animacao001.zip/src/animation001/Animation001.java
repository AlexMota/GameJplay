package animation001;

import jplay.Animation;
import jplay.GameImage;
import jplay.Window;

 /**
  * @author Gefersom Cardoso Lima
  * Federal Fluminense University - UFF - Brazil
  * Computer Science
  */
 
public class Animation001 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
            Window janela = new Window(800,600);
            GameImage fundo = new GameImage("fundo.png");
            Animation animacao = new Animation("animacao.png", 4);
            animacao.setTotalDuration(500);

            while(true)
            {
                fundo.draw();
                animacao.draw();
                janela.update();
                animacao.update();
            }
    }

}
