package Animation003;

import jplay.Animation;
import jplay.GameImage;
import jplay.Keyboard;
import jplay.Window;
import java.awt.Color;

 /**
  * @author Gefersom Cardoso Lima
  * Federal Fluminense University - UFF - Brazil
  * Computer Science
  */

//Accelerate or decelerate a frameset.
public class Animation003
{
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
            Window janela = new Window(800,600);
            GameImage fundo = new GameImage("fundo.png");
            Animation animacao = new Animation("inuyasha.png", 13);
            Keyboard teclado = janela.getKeyboard();
            animacao.setTotalDuration(1000000);

            animacao.y = 250;
            animacao.x = 200;

            while(true)
            {
                fundo.draw();
                animacao.draw();
                janela.drawText("Press Space Bar to accelerate or Enter to decelerate.", 200, 210, Color.yellow);
                janela.update();

                if (teclado.keyDown(Keyboard.ENTER_KEY))
                {
                    animacao.setSequenceTime(0, 12, 6000);
                }
                else
                {
                    if (teclado.keyDown(Keyboard.SPACE_KEY))
                        animacao.setSequenceTime(0, 12, 1500);
                }

                animacao.update();

            }
    }

}
