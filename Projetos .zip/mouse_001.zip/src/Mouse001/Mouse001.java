package Mouse001;

import java.awt.Point;
import jplay.GameImage;
import jplay.Keyboard;
import jplay.Mouse;
import jplay.Window;

 /**
  * @author Gefersom Cardoso Lima
  * Federal Fluminense University - UFF - Brazil
  * Computer Science
  */

public class Mouse001
{
    public static void main(String[] args)
    {
        Window janela = new Window(800,600);
        Keyboard keyboard = janela.getKeyboard();
        Mouse mouse = janela.getMouse();

        GameImage backGround = new GameImage("fundo.png");
        GameImage imagem = new GameImage("megaMan.png");

        boolean executando = true;
        while(executando)
        {
                backGround.draw();
                imagem.draw();
                janela.update();

                //If the left button clicked the image will appear where there was the click.
                if (mouse.isLeftButtonPressed() == true)
                {
                    Point posicao = mouse.getPosition();
                    imagem.x = posicao.x;
                    imagem.y = posicao.y;
                }

                if ( keyboard.keyDown(Keyboard.ESCAPE_KEY) == true)
                    executando = false;
        }
        janela.exit();
    }
}
