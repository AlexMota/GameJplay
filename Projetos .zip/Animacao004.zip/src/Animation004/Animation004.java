/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Animation004;

import jplay.Animation;
import jplay.GameImage;
import jplay.Keyboard;
import jplay.Window;

 /**
  * @author Gefersom Cardoso Lima
  * Federal Fluminense University - UFF - Brazil
  * Computer Science
  */

//It sets the frame to be drawn.
public class Animation004
{
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
            Window janela = new Window(800,600);
            GameImage fundo = new GameImage("paisagem.png");
            Animation animacao = new Animation("navio.png", 2);
            Keyboard teclado = janela.getKeyboard();
          
            animacao.y = 250;
            animacao.x = 200;

            while(true)
            {
                fundo.draw();
                animacao.draw();
                janela.update();

                if (teclado.keyDown(Keyboard.LEFT_KEY))
                    animacao.setCurrFrame(0);
                else
                {
                    if (teclado.keyDown(Keyboard.RIGHT_KEY))
                        animacao.setCurrFrame(1);
                }

            }
    }

}
