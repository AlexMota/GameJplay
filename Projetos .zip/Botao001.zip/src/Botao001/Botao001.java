package Botao001;

import jplay.Animation;
import jplay.GameImage;
import jplay.Mouse;
import jplay.Window;

/**
 * @author Gefersom Cardoso Lima
 * Federal Fluminense University
 * Computer Science
 */

public class Botao001
{
    //Creates a button.
    public static void main(String[] args)
    {
            Window janela = new Window(800,600);
            Mouse mouse = janela.getMouse();

            GameImage backGround = new GameImage("fundo.png");
           
            Animation botao = new Animation("botao.png",12);

            botao.x = 350;
            botao.y = 330;
            botao.setTotalDuration(1200);
            botao.setLoop(false);
            botao.stop();

            boolean executando = true;
            while(executando)
            {
                    backGround.draw();
                    botao.draw();
                    janela.update();
                    
                    if (mouse.isOverObject(botao) && mouse.isLeftButtonPressed())
                    {
                        botao.stop();
                        botao.play();
                    }

                    botao.update();
            }
            janela.exit();
    }
}
