/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Sprite001;

import JPlay.GameImage;
import JPlay.Sprite;
import JPlay.Window;

/**
 * @author Gefersom Cardoso Lima
 * Federal Fluminense University
 * Computer Science
 */

//Creates a sprite.
public class Sprite001
{
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
            Window janela = new Window(800,600);
            GameImage fundo = new GameImage("fundo.png");
            Sprite inuyasha = new Sprite("inuyasha.png", 13);

            inuyasha.y = 250;
            inuyasha.x = 200;

            inuyasha.setSequence(0, 2);
            inuyasha.setTotalDuration(1200);
            while(true)
            {
                fundo.draw();
                inuyasha.draw();
                janela.display();

                inuyasha.
                inuyasha.update();
            }
    }

}
