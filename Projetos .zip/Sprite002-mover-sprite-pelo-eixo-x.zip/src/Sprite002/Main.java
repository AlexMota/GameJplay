package Sprite002;

import JPlay.Keyboard;
import JPlay.Sprite;
import JPlay.Window;
import java.awt.Color;
import java.awt.Event;
import java.awt.event.KeyEvent;

/**
 * @author Gefersom Cardoso Lima
 * Federal Fluminense University
 * Computer Science
 */

public class Main
{
	//Move the sprite by the x-axis
	public static void main(String[] args)
	{
		Window janela = new Window(800,600);
		Keyboard teclado = janela.getKeyboard();
		teclado.addKey(KeyEvent.VK_N, Keyboard.DETECT_EVERY_PRESS);

		Sprite sprite = new Sprite("boia.png");
		sprite.y = 250;
		sprite.x = 350;

		boolean executando = true;
		while(executando)
		{
				janela.clear(Color.black);
				sprite.draw();
				janela.display();

				if(teclado.keyDown(Keyboard.LEFT_KEY))
					sprite.x -= 3;
				else
					if( teclado.keyDown(Keyboard.RIGHT_KEY))
						sprite.x += 3;

				janela.delay(10);

				if (teclado.keyDown(KeyEvent.VK_N) == true)
					executando = false;

		}
		janela.exit();
	}
}