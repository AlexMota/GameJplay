package Animation005;

import jplay.Animation;
import jplay.GameImage;
import jplay.Keyboard;
import jplay.Window;

 /**
  * @author Gefersom Cardoso Lima
  * Federal Fluminense University - UFF - Brazil
  * Computer Science
  */

//Frames have different times of change
public class Animation005
{
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
            Window janela = new Window(800,600);
            GameImage fundo = new GameImage("paisagem.png");
            Animation animacao = new Animation("fotos.png", 8);

            animacao.setDuration(0, 2000);
            animacao.setDuration(1, 1800);
            animacao.setDuration(2, 1600);
            animacao.setDuration(3, 1400);
            animacao.setDuration(4, 1200);
            animacao.setDuration(5, 1000);
            animacao.setDuration(6, 800);
            animacao.setDuration(7, 600);
            animacao.loop(false);
            while(true)
            {
                fundo.draw();
                animacao.draw();
                janela.update();

                animacao.update();
            }
    }

}
