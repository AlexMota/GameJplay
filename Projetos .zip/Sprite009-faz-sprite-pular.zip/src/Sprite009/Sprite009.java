package Sprite009;

import JPlay.GameImage;
import JPlay.Keyboard;
import JPlay.Sprite;
import JPlay.Window;
import java.awt.event.KeyEvent;

/**
 * @author Gefersom Cardoso Lima
 * Federal Fluminense University
 * Computer Science
 */
 
public class Sprite009
{
    //Makes the sprite to jump.
    public static void main(String[] args)
    {
        Window janela = new Window(800,600);
        GameImage backGround = new GameImage("cena.png");

        Sprite sprite = new Sprite("mario.png");
        sprite.y = 440 - sprite.height;
        sprite.x = 250;
        sprite.setFloor(440);

        while(true)
        {
                backGround.draw();
                sprite.draw();
                janela.display();

                sprite.jump();
                janela.delay(10);
        }
    }
}
