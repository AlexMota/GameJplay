/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package scenariotest;

/**
 *
 * @author David
 */
public class Constante
{
        public static int TILE_WALL = 1;
        public static int TILE_STAR = 3;
        public static int TILE_EXIT = 4;
}