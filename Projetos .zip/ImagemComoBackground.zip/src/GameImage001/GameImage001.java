package GameImage001;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import jplay.GameImage;
import jplay.Window;

/**
 * @author Gefersom Cardoso Lima
 * Federal Fluminense University - UFF - Brazil
 * Computer Science
 */
public class GameImage001
{
    //Mostra uma imagem como backGround
    public static void main(String[] args)
    {
        Window janela = new Window(800,600);
        GameImage backGround = new GameImage("fundo.png");

        while(true)
        {
                backGround.draw();

                //Esse comando sempre deve ser chamado por último, é obrigatório,
                //em relação a parte de desenhar na tela.
                janela.update();
        }
    }
}
