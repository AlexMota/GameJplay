package Sprite004;

import JPlay.GameImage;
import JPlay.Keyboard;
import JPlay.Sprite;
import JPlay.Window;

/**
 * @author Gefersom Cardoso Lima
 * Federal Fluminense University
 * Computer Science
 */
public class Sprite004
{
    //Move the sprite by  y-axis
    public static void main(String[] args)
    {
        Window janela = new Window(800,600);
        Keyboard keyboard = janela.getKeyboard();

        GameImage backGround = new GameImage("mar.png");

        Sprite sprite = new Sprite("boia.png");
        sprite.y = 450;
        sprite.x = 300;

        while(true)
        {
                backGround.draw();
                sprite.draw();
                janela.display();

                if( keyboard.keyDown(Keyboard.UP_KEY) )
                    sprite.y -= 7;
                else
                    if( keyboard.keyDown(Keyboard.DOWN_KEY) )
                        sprite.y += 7;

                janela.delay(50);
        }
    }
}
