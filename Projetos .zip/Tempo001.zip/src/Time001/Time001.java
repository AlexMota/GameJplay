package Time001;

import jplay.GameImage;
import jplay.Keyboard;
import jplay.Time;
import jplay.Window;
import java.awt.Color;

/**
 * @author Gefersom Cardoso Lima
 * Federal Fluminense University
 * Computer Science
 */

public class Time001
{
    //Show on the screen a regressive and a rising time.
    public static void main(String[] args)
    {
            Window janela = new Window(800,600);
            Keyboard keyboard = janela.getKeyboard();
            GameImage backGround = new GameImage("fundo.png");

            Time tempo1 = new Time(100, 100,true);
            tempo1.setColor(Color.yellow);

            Time tempo2 = new Time(1, 39, 56, 100, 200,false);
            tempo2.setColor(Color.cyan);

            boolean executando = true;

            while(executando)
            {
                    backGround.draw();
                    tempo1.draw("Progressivo: ");
                    tempo2.draw("Regressivo:  ");
                    janela.update();

                    if ( keyboard.keyDown(Keyboard.ESCAPE_KEY) == true )
                        executando = false;
            }
            janela.exit();
    }
}
