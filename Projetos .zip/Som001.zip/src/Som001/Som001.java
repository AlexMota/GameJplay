/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Som001;

import jplay.Animation;
import jplay.GameImage;
import jplay.Sound;
import jplay.Sprite;
import jplay.Window;

/**
 * @author Gefersom Cardoso Lima
 * Universidade Federal Fluminense - UFF - Brasil - 2010
 * Ciência da Computação
 */

public class Som001
{
    //At the time the bird colliding with the rock it explodes and a sound plays.
    public static void main(String[] args)
    {
            Window janela = new Window(800,600);

            GameImage pedra = new GameImage("pedra.png");
            pedra.x = 396;
            pedra.y = 63;

            GameImage ceu = new GameImage("ceu.png");
            Sprite passaro = new Sprite("passaro.png", 3);
            passaro.setTotalDuration(360);

            Animation explosao = new Animation("explosao.png",20);
            explosao.setTotalDuration(1400);
            explosao.setLoop(false);//The animation will run only once.

            passaro.x = 100;
            passaro.y = 460;

            boolean colidiu = false;
            while(true)
            {
                    ceu.draw();
                    pedra.draw();

                    if (colidiu == false)
                    {
                        passaro.draw();
                        passaro.update();
                        passaro.moveTo(600, passaro.y, 0.8);
                        if (passaro.collided(pedra))
                        {
                            colidiu = true;
                            explosao.x = passaro.x - 70;
                            explosao.y = passaro.y - 50;
                            new Sound("explosao.wav").play();
                        }
                    }
                    else
                    {
                        explosao.update();
                        explosao.draw();
                    }

                    if (explosao.isPlaying() == false && colidiu == true)
                        explosao.hide();

                    janela.update();
                    janela.delay(10);
            }
    }
}
