/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Sprite007;


import JPlay.GameImage;
import JPlay.Sprite;
import JPlay.Window;

/**
 * @author Gefersom Cardoso Lima
 * Federal Fluminense University
 * Computer Science
 */
public class Sprite007
{
    //Moves the sprite using the following methods: void moveY(double) and void moveX(double).
    public static void main(String[] args)
    {
        Window janela = new Window(800,600);

        GameImage backGround = new GameImage("mar.png");

        Sprite sprite = new Sprite("boia.png");
        sprite.y = 400;
        sprite.x = 300;

        while(true)
        {
                backGround.draw();
                sprite.draw();
                janela.display();

                //Move by y-axis
                sprite.moveY(12);//velocity = 1

                //Move by x-axis
                sprite.moveX(1);//velocity = 1
        }
    }
}
