package animation002;

import jplay.Animation;
import jplay.GameImage;
import jplay.Window;

 /**
  * @author Gefersom Cardoso Lima
  * Federal Fluminense University - UFF - Brazil
  * Computer Science
  */

public class Animation002 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
            Window janela = new Window(800,600);
            GameImage fundo = new GameImage("fundo.png");
            GameImage megaMan = new GameImage("animacaoMenor.png");
            Animation animacao = new Animation("animacao.png", 28);

            animacao.setTotalDuration(2000);
            animacao.setSequence(0, 13);
            animacao.y = 250;
            animacao.x = 200;

            megaMan.y = 150;

            while(true)
            {
                fundo.draw();
                megaMan.draw();
                animacao.draw();
                janela.update();

                animacao.update();
            }
    }

}
