/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cenario_ex2;

/**
 * @author Gefersom Cardoso Lima
 * Federal Fluminense University
 * Computer Science
 */


 public class Constante
 {
         public static int TILE_WALL = 1;
         public static int TILE_STAR = 3;
 }
