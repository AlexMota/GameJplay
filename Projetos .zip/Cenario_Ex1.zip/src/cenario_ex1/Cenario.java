package cenario_ex1;


 import jplay.Scene;
 import jplay.Window;

 /**
  * @author Gefersom Cardoso Lima
  * Federal Fluminense University
  * Computer Science
  */

 public class Cenario {

     private Window window;
     private Scene scene;

     public Cenario()
     {
             window = new Window(800,600);
             scene = new Scene();
             scene.loadFromFile("scene.scn");
             scene.setDrawStartPos(15, 30);

     }

     public void run()
     {
             while(true)
             {
                 scene.draw();
                 window.update();
             }
     }

     /**
      * @param args the command line arguments
      */
     public static void main(String[] args) {
         Cenario cen = new Cenario();
         cen.run();
     }
 }