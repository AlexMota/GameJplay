package Sprite012;

import JPlay.GameImage;
import JPlay.Sprite;
import JPlay.Window;

/**
 * @author Gefersom Cardoso Lima
 * Federal Fluminense University
 * Computer Science
 */
public class Sprite012
{
    //Moves the sprite from one point to another.
    public static void main(String[] args)
    {
        Window janela = new Window(800,565);
        GameImage backGround = new GameImage("estrada.jpg");

        Sprite sprite = new Sprite("bola.png");
        sprite.y = 280;
        sprite.x = 100;

        backGround.draw();
        sprite.draw();
        janela.display();
        janela.delay(2000);

        while(true)
        {
                backGround.draw();
                sprite.draw();
                janela.display();
                sprite.moveTo(490, sprite.y , 2);

                if (sprite.x == 490)
                    sprite.moveTo(sprite.x, 35, 1);

                janela.delay(4);
        }
    }
}
