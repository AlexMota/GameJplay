package Sprite006;

import JPlay.GameImage;
import JPlay.Keyboard;
import JPlay.Sprite;
import JPlay.Window;

/**
 * @author Gefersom Cardoso Lima
 * Federal Fluminense University
 * Computer Science
 */
public class Sprite006
{
    //Delimited area of motion
    public static void main(String[] args)
    {
        Window janela = new Window(800,600);
        Keyboard keyboard = janela.getKeyboard();

        GameImage backGround = new GameImage("mar.png");

        Sprite sprite = new Sprite("boia.png");
        sprite.y = 400;
        sprite.x = 300;

        while(true)
        {
                backGround.draw();
                sprite.draw();
                janela.display();

                //Moves by y-axis
                if(keyboard.keyDown(Keyboard.UP_KEY) && sprite.y > 0)
                    sprite.y--;
                else
                    if( keyboard.keyDown(Keyboard.DOWN_KEY) && sprite.y  + sprite.height < janela.getHeight())
                        sprite.y++;

                //Moves by x-axis
                if(keyboard.keyDown(Keyboard.LEFT_KEY) && sprite.x > 100)
                    sprite.x--;
                else
                    if( keyboard.keyDown(Keyboard.RIGHT_KEY) && sprite.x  + sprite.width < 650)
                        sprite.x++;
        }
    }
}
